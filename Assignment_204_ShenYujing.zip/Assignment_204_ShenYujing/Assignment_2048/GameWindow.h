#ifndef GameWindow_h
#define GameWindow_h

#include "Game.h"

class GameWindow
{
public:
	static void Init(int &argc, char *argv[]);
	static void Start();

private:

	static Game game;
	static void BackGroundInit();
	static void Reshape(GLsizei w, GLsizei h);
	static void Display();
	static void KeyboardAction(unsigned char key,int x,int y);
	static void Action();
};


#endif