

#include "Constants.h"


const double Constants::Edge = 0.3;
const double Constants::BtwEdge = 0.02;
const double Constants::halfBtwEdge = 0.01;
const double Constants::displaceY = -0.15;



const char* Constants::Title = "2048 by SYJ";
const char* Constants::Numbers[10]=
{
	"2","4","8","16","32","64","128","256","512","1024",
};
const char* Constants::Scores = "Scores:";
const char* Constants::Restart ="Restart (R)";
const char* Constants::Finished = "FINISHED!";

const double Constants::EPS = 0.001;

const double Constants::BlocksColor[11][3] =
{
	(double)0xd9 / (double)0xff , (double)0xd9 / (double)0xff, (double)0xd9 / (double)0xff ,
	(double)0xff / (double)0xff , (double)0xe0 / (double)0xff, (double)0x00 / (double)0xff ,
	(double)0xff / (double)0xff , (double)0xb3 / (double)0xff, (double)0x00 / (double)0xff ,
	(double)0xff / (double)0xff , (double)0x92 / (double)0xff, (double)0x00 / (double)0xff ,
	(double)0xff / (double)0xff , (double)0x81 / (double)0xff, (double)0x00 / (double)0xff ,
	(double)0xff / (double)0xff , (double)0x64 / (double)0xff, (double)0x00 / (double)0xff ,
	(double)0xff / (double)0xff , (double)0x52 / (double)0xff, (double)0x00 / (double)0xff ,
	(double)0xff / (double)0xff , (double)0x42 / (double)0xff, (double)0x00 / (double)0xff ,
	(double)0xff / (double)0xff , (double)0x30 / (double)0xff, (double)0x00 / (double)0xff ,
	(double)0xff / (double)0xff , (double)0x1d / (double)0xff, (double)0x00 / (double)0xff ,
	(double)0xff / (double)0xff , (double)0x09 / (double)0xff, (double)0x00 / (double)0xff ,
};


const double Constants::MtrxX1[6] = 
{
	-halfBtwEdge-3*Edge-2*BtwEdge, -halfBtwEdge-2*Edge-1*BtwEdge,-halfBtwEdge-1*Edge,
	halfBtwEdge, halfBtwEdge+1*Edge+1*BtwEdge, halfBtwEdge+2*Edge+2*BtwEdge,
};

const double Constants::MtrxX2[6]=
{
	-halfBtwEdge-2*Edge-2*BtwEdge, -halfBtwEdge-1*Edge-1*BtwEdge, -halfBtwEdge, 
	halfBtwEdge+1*Edge, halfBtwEdge+2*Edge+1*BtwEdge, halfBtwEdge+3*Edge+2*BtwEdge,
};

const double Constants::MtrxY1[6]=
{
	-halfBtwEdge-3*Edge-2*BtwEdge + displaceY, -halfBtwEdge-2*Edge-1*BtwEdge + displaceY,
	-halfBtwEdge-1*Edge +displaceY, halfBtwEdge + displaceY,
	halfBtwEdge+1*Edge+1*BtwEdge + displaceY, halfBtwEdge+2*Edge+2*BtwEdge + displaceY,
};

const double Constants::MtrxY2[6]=
{
	-halfBtwEdge-2*Edge-2*BtwEdge + displaceY, -halfBtwEdge-1*Edge-1*BtwEdge + displaceY, 
	-halfBtwEdge + displaceY, halfBtwEdge+1*Edge + displaceY, 
	halfBtwEdge+2*Edge+1*BtwEdge + displaceY, halfBtwEdge+3*Edge+2*BtwEdge + displaceY,
};