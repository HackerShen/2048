
#include "GameWindow.h"



Game GameWindow::game(2);

void GameWindow::Init(int &argc, char *argv[])
{
	
	glutInit(&argc,argv);

	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA | GLUT_DEPTH);

	glutInitWindowSize(500, 600);
	glutInitWindowPosition(350,50);
	glutCreateWindow(Constants::Title);

	BackGroundInit();

	game.init();

	// ֱ��displayfunc ������Idle �� reshap �ź�ͼ���
	glutReshapeFunc( Reshape );
	glutDisplayFunc( Display );
	
	glutIdleFunc(Action);

	// ֱ��ͼ�������ſ��Ե��ü���
	glutKeyboardFunc(KeyboardAction);

}



void GameWindow::BackGroundInit()
{
	glClearColor(1.0,1.0,1.0,1.0);
	glShadeModel(GL_FLAT);

}


void GameWindow::Start()
{
	glutMainLoop();
}

void GameWindow::Display()
{
	//TODO  ��������
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	

	game.DrawGameStates();


	//TODO SwapBuffer ��ֹͼƬ�ڳ�ˢʱ������Ƭ
	glutSwapBuffers();
	glFlush();
}

void GameWindow::Reshape(GLsizei w, GLsizei h)
{
	glViewport(0, 0, w, h);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	
	//TODO ���� ���ر�
	GLfloat factor = (GLfloat)w/(GLfloat)h;
	if (w < h) 
		gluOrtho2D (-1.0, 1.0, -1.0 / factor, 1.0 / factor);
	else 
		gluOrtho2D (-1.0 * factor, 1.0 *factor, -1.0, 1.0);

	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
}

void GameWindow::Action()
{
	if(game.isState(Constants::Moving))
	{
		if(! game.MovebySteps() )
		{
			game.StopMoving();
			game.setSate(Constants::Ready);
			game.NewBlocks();
		}
		game.UpDate();
	}

	if(game.isState(Constants::Stopped))
	{
		game.DrawText(0.0,1.0,Constants::Finished);
		game.UpDate();
	}
}


void GameWindow::KeyboardAction(unsigned char key,int x,int y)
{
	switch (key)
	{
	case 'w': case 'W': 
		game.toUp();
		break;
	case 's': case 'S':
		game.toDown();
		break;
	case 'a': case 'A':
		game.toLeft();
		break;
	case 'd': case 'D':
		game.toRight();
		break;
	case 'r': case 'R':
		game.init();
		game.UpDate();
		break;
	}
}



// 			glVertex2d(Constants::MtrxX1[j],Constants::MtrxY1[i]);
// 			glVertex2d(Constants::MtrxX2[j],Constants::MtrxY1[i]);
// 			glVertex2d(Constants::MtrxX2[j],Constants::MtrxY2[i]);
// 			glVertex2d(Constants::MtrxX1[j],Constants::MtrxY2[i]);



// 	int len = 0;
// 	for(int i = 0; i < 6; ++i)
// 		for(int j = 0; j < 6; ++j)
// 		{
// 			glColor3dv(Constants::BlocksColor[len]);
// 			if(len < 10) ++len;
// 			glRectd(Constants::MtrxX1[j],Constants::MtrxY1[i],Constants::MtrxX2[j],Constants::MtrxY2[i]);
// 
// 		}
