
// Game.h


#ifndef Game_h
#define Game_h

#include <cstring>
#include <stdlib.h>
#include <time.h>

#include <GL/glut.h>
// #include <cstdlib>
// #include <ctime>

#include "Blocks.h"



class Game
{
public:
	Game(int n);
	~Game();
	void init();
	
	//TODO ��display func ����ʾ
	void DrawGameStates();

	//TODO �޸�״̬
	void toUp();
	void toDown();
	void toLeft();
	void toRight();

	//TODO �趨״̬
	void setSate(int STATE);
	
	//TODO ����
	bool MovebySteps();

	//TODO �������
	void StopMoving();

	//TODO �����µ�block
	void NewBlocks();

	//TODO ��ȡ״̬
	bool isState(int STATE);

	//TODO ����״̬
	void UpDate();

	void DrawText(double x, double y, const char *str);
	
private:
	void Num2String(int x, char *str);
	void DrawScores();
	void DrawNumbers(const double *p1,const double *p2,int x);

	bool UpaStep();
	bool DownaStep();
	bool LeftaStep();
	bool RightaStep();

	void clearMotion();

	int p_gameState;
	int p_blocks_num;
	int p_gamescores;
	Blocks p_blocks[6][6];
	Blocks p_tomove[6][6];
	int p_tochange[6][6];
};


#endif