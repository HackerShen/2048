
// openGL_2


#include "GameWindow.h"


int main(int argc, char *argv[])
{
	srand(time(NULL));

	GameWindow::Init(argc, argv);
	
	GameWindow::Start();

	return 0;
}