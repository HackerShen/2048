

//Blockes.h
#ifndef Blocks_h
#define Blocks_h

#include "Constants.h"

class Blocks
{
public:
	Blocks();
	Blocks(int i, int j, int n = 0);
	Blocks(const Blocks &rhs);

	~Blocks();

	Blocks& operator=(const Blocks &rhs);

	// TODO �Ƚ� Num
	bool operator==(const Blocks &rhs) const ;

	// TODO Num ++ 
	void operator++();

	bool move(int i,int j);

	int& Num();

	const double* P1() const;

	const double* P2() const;

private:
	double mp1[2],mp2[2];
/*	double mvp1[2],mvp2[2];*/
	int num;

	double abs(double x)
	{
		if(x >= 0) return x;
		else return -x;
	}

	double Step(double st, double ed)
	{
		return (ed - st) / 55.0;
	}
};



#endif // !Blocks_h
