

// Constants.h

#ifndef Constants_h
#define Constants_h 

class Constants
{
public:
	// TODO  const strings
	static const char *Title;
	static const char *Numbers[10];
	static const char *Scores;
	static const char *Restart;
	static const char *Finished;

	// TODO Blocks
	static const double MtrxX1[6];
	static const double MtrxY1[6];
	static const double MtrxX2[6];
	static const double MtrxY2[6];

	//TODO Colors
	static const double BlocksColor[11][3];

	//TODO �Զ���
	static const int Ready = 1;
	static const int Busy = 2;
	static const int Stopped = 3;
	static const int Moving = 4;

	//TODO helper
	static const double EPS;

	static const double Edge;
	static const double BtwEdge;
	static const double halfBtwEdge;
	static const double displaceY;
};

#endif



//	static const double BtwBound;
// 	static const double BoundX1;
// 	static const double BoundX2;
// 	static const double BoundY1;
// 	static const double BoundY2;
// const double Constants::BtwBound = 0.05;
// const double Constants::BoundX1 = -1.0;
// const double Constants::BoundX2 = 1.0;
// const double Constants::BoundY1 = -1.0;
// const double Constants::BoundY2 = 1.0;