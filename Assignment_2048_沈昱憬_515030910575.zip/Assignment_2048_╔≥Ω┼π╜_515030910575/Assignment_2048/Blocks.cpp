

#include "Blocks.h"


Blocks::Blocks():num(0)
{}

Blocks::Blocks(int i, int j, int n /* = 0 */):num(n)
{
	mp1[0] = Constants::MtrxX1[i];
	mp1[1] = Constants::MtrxY1[j];
	mp2[0] = Constants::MtrxX2[i];
	mp2[1] = Constants::MtrxY2[j];

/*	mvp1[0] = mvp1[1] = mvp2[0] = mvp2[1] = 0.0;*/
}

Blocks::Blocks(const Blocks &rhs):num(rhs.num)
{
	mp1[0] = rhs.mp1[0];
	mp1[1] = rhs.mp1[1];
	mp2[0] = rhs.mp2[0];
	mp2[1] = rhs.mp2[1];

// 	mvp1[0] = rhs.mvp1[0];
// 	mvp1[1] = rhs.mvp1[1];
// 	mvp2[0] = rhs.mvp2[0];
// 	mvp2[1] = rhs.mvp2[1];
}

Blocks::~Blocks()
{
}

Blocks& Blocks::operator=(const Blocks &rhs)
{
	num = rhs.num;

	mp1[0] = rhs.mp1[0];
	mp1[1] = rhs.mp1[1];
	mp2[0] = rhs.mp2[0];
	mp2[1] = rhs.mp2[1];

// 	mvp1[0] = rhs.mvp1[0];
// 	mvp1[1] = rhs.mvp1[1];
// 	mvp2[0] = rhs.mvp2[0];
// 	mvp2[1] = rhs.mvp2[1];

	return *this;
}

bool Blocks::operator==(const Blocks &rhs) const
{
	return num == rhs.num;
}

void Blocks::operator++()
{
	++num;
}

int& Blocks::Num()
{
	return num;
}

const double* Blocks::P1() const
{
	return mp1;
}

const double* Blocks::P2() const
{
	return mp2;
}



bool Blocks::move(int i,int j)
{
	int is_move = 0;

	double x1=mp1[0];
	double y1=mp1[1];

	double x2=mp2[0];
	double y2=mp2[1];

	double t_x1=Constants::MtrxX1[i];
	double t_x2=Constants::MtrxX2[i];
	double t_y1=Constants::MtrxY1[j];
	double t_y2=Constants::MtrxY2[j];

	double EPS = Constants::EPS;

	//
	if(abs(x1 - t_x1) < EPS)
	{
		mp1[0] = t_x1;
		++is_move;
	}else
	{
		mp1[0] += Step(x1, t_x1);
	}
	//
	if(abs(x2 - t_x2) < EPS)
	{
		mp2[0] = t_x2;
		++is_move;
	}else
	{
		mp2[0] += Step(x2, t_x2);
	}
	//
	if(abs(y1 - t_y1) < EPS)
	{
		mp1[1] = t_y1;
		++is_move;
	}else
	{
		mp1[1] += Step(y1, t_y1);
	}
	//
	if(abs(y2 - t_y2) < EPS)
	{
		mp2[1] = t_y2;
		++is_move;
	}else
	{
		mp2[1] += Step(y2, t_y2);
	}

	//
	if(is_move == 4)
	{
		num %= 11;
		return 0;
	}else
	{
		return 1;
	}
}
