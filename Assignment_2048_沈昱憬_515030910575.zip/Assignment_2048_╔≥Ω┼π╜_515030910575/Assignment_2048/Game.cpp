
#include "Game.h"
#include <iostream>

Game::Game(int n)//:p_blocks_num(n),p_gameState(Constants::Ready)
{
	init();
}

Game::~Game()
{}

void Game::DrawGameStates()
{
	DrawText(-0.9, 1.0, Constants::Scores);
	DrawText(0.5, 1.0,  Constants::Restart);
	DrawScores();

	//TODO ����ֿ������໥�ڵ�
	for(int i = 0; i < 6; ++i)
	{
		for(int j  = 0; j < 6; ++j)
		{
			glColor3dv(Constants::BlocksColor[p_blocks[i][j].Num()]);
			glRectdv(p_blocks[i][j].P1(),p_blocks[i][j].P2());
			if(p_blocks[i][j].Num()!=0)
			{
				DrawNumbers(p_blocks[i][j].P1(),p_blocks[i][j].P2(),p_blocks[i][j].Num());
			}
		}
	}

	for(int i = 0; i < 6; ++i)
	{
		for(int j = 0; j < 6; ++j)
		{
			if(p_tomove[i][j].Num() != 0)
			{
				glColor3dv(Constants::BlocksColor[p_tomove[i][j].Num()]);
				glRectdv(p_tomove[i][j].P1(),p_tomove[i][j].P2());	
				DrawNumbers(p_tomove[i][j].P1(),p_tomove[i][j].P2(),p_tomove[i][j].Num());
			}
		}
	}
}

void Game::DrawText(double x, double y, const char *str)
{
	glColor3d(1.0,0.1,0.0);
	glRasterPos2d(x,y);

	for(int i = 0; str[i]; ++i)
	{
		glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, str[i]);
	}
}


void Game::DrawScores()
{
	char str[100];
	Num2String(p_gamescores ,str);
	
	DrawText(-0.6,1.0, str);
}

void Game::DrawNumbers(const double *p1,const double *p2,int num)
{
	double x = (p1[0] + p2[0]) / 2;
	double y = (p1[1] + p2[1]) / 2;
	char str[100];
	Num2String(1<<num,str);
	int len = strlen(str) / 2;
	x -= Constants::Edge / 8 * len;

	glColor3d(1.0,1.0,1.0);
	glRasterPos2d(x - 0.01,y - 0.024);
	for(int i = 0; str[i]; ++i)
	{
		glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24,str[i]);
	}

}

void Game::Num2String(int x, char *str)
{
	char tmp[100];
	int len = 0;
	if(x == 0)
	{
		str[0] = '0';
		str[1] = '\0';
		return ;
	}

	while(x)
	{
		tmp[len++] = x % 10 + '0';
		x /= 10;
	}
	for(int i = 0; i < len; i++)
		str[i] = tmp[len - i -1];
	str[len] = '\0';
}

void Game::init()
{
	p_gamescores = p_blocks_num = 0;
	setSate((Constants::Ready));

	for(int i = 0; i < 6; ++i)
	{
		for(int j = 0; j < 6; ++j)
		{

			p_tomove[i][j] = p_blocks[i][j] = Blocks(i,j);
			p_tochange[i][j] = 0;
		}
	}

	NewBlocks();
	NewBlocks();
}

void Game::UpDate()
{
	glutPostRedisplay();
}


void Game::NewBlocks()
{
	if(! isState(Constants::Ready) || p_blocks_num == 36)
	{
		return ;
	}
	setSate(Constants::Busy);
	int x = -1, y = -1;



	if(p_blocks_num <= 30)
	{
		x = 6 * rand() / (RAND_MAX + 1);
		y = 6 * rand() / (RAND_MAX + 1);
		while(p_blocks[x][y].Num() != 0)
		{
			x = 6 * rand() / (RAND_MAX + 1);
			y = 6 * rand() / (RAND_MAX + 1);
		}
	}else
	{
		for(int i = 0; i < 6; ++i)
		{
			for(int j = 5; j >= 0; --j)
			{
				if(p_blocks[i][j].Num() == 0)
				{
					x = i; y = j;
					break;
				}
			}
			if(x >= 0)
			{
				break;
			}
		}
	}

	if(x >= 0)
	{
		p_blocks[x][y] = Blocks(x,y,1);
		++p_blocks_num;
	}
	setSate(Constants::Ready);


	bool isOK=0;
	for(int i = 0; i < 6; ++i)
	{
		for(int j = 0; j < 6; ++j)
		{
			if(p_blocks[i][j].Num() == 0)
			{
				isOK = 1;
				break;
			}
			if(j+1 < 6 && p_blocks[i][j].Num() == p_blocks[i][j+1].Num())
			{
				isOK = 1;
				break;
			}
			if(i+1 < 6 && p_blocks[i][j].Num() == p_blocks[i+1][j].Num())
			{
				isOK = 1;
				break;
			}
		}
	}
	if (!isOK)
	{
		setSate(Constants::Stopped);
	}
}



bool Game::MovebySteps()
{
	bool isMoving = 0;

	isMoving = 0;
	for(int i = 0; i < 6; ++i)
	{
		for(int j = 0; j < 6; ++j)
		{
			if(p_tomove[i][j].move(i,j))
			{
				isMoving = 1;
			}
		}
	}
	return isMoving;
}

void Game::StopMoving()
{
	for(int i = 0; i < 6; ++i)
	{
		for(int j = 0; j < 6; ++j)
		{
			if(p_tochange[i][j] != 0 || p_tochange[i][j] == 11)
			{
				p_tomove[i][j].Num() = p_tochange[i][j];
				p_tochange[i][j] = 0;
			}
			if(p_tomove[i][j].Num() != 0)
			{
				p_blocks[i][j] = Blocks(i,j,(p_tomove[i][j].Num() % 11));
				p_tomove[i][j] = Blocks(i,j);
			}
		}
	}
}

void Game::setSate(int STATE)
{
	p_gameState = STATE;
}

bool Game::isState(int STATE)
{
	return p_gameState == STATE;
}


void Game::clearMotion()
{
	for(int i = 0; i < 6; ++i)
	{
		for(int j = 0; j < 6; ++j)
		{
			p_tomove[i][j] = Blocks(i,j);
			p_tochange[i][j] = 0;
		}
	}
}



void Game::toUp()
{
	if(!isState(Constants::Ready))
	{
		return ;
	}

	setSate(Constants::Busy);
	clearMotion();

	if(UpaStep())
	{
		setSate(Constants::Moving);
	}

	if(isState(Constants::Busy))
	{
		setSate(Constants::Ready);
	}

}


void Game::toDown()
{
	if(!isState(Constants::Ready))
	{
		return ;
	}

	setSate(Constants::Busy);
	clearMotion();

	if(DownaStep())
	{
		setSate(Constants::Moving);
	}

	if(isState(Constants::Busy))
	{
		setSate(Constants::Ready);
	}

}

void Game::toLeft()
{
	if(!isState(Constants::Ready))
	{
		return ;
	}

	setSate(Constants::Busy);
	clearMotion();

	if(LeftaStep())
	{
		setSate(Constants::Moving);
	}

	if(isState(Constants::Busy))
	{
		setSate(Constants::Ready);
	}

}

void Game::toRight()
{
	if(!isState(Constants::Ready))
	{
		return ;
	}

	setSate(Constants::Busy);
	clearMotion();

	if(RightaStep())
	{
		setSate(Constants::Moving);
	}

	if(isState(Constants::Busy))
	{
		setSate(Constants::Ready);
	}

}

bool Game::UpaStep()
{

	bool isMoving = 0;
	Blocks tmp[6][6];
	bool beMerged[6][6];
	for(int i = 0; i < 6; ++i)
	{
		for(int j = 0; j < 6; ++j)
		{
			tmp[i][j] = p_blocks[i][j];
			beMerged[i][j] = 0;
		}
	}
	for(int i = 0; i < 6; ++i)
	{
		for(int j = 4; j >= 0; --j)
		{

			if(p_blocks[i][j].Num() == 0)
			{
				continue;
			}

			int k = j + 1;
			bool oneBlockMove = 1;
			bool cancopy = 1;
			while(k <= 5 && oneBlockMove)
			{
				oneBlockMove = 0;
				if(tmp[i][k].Num() == 0)
				{
					oneBlockMove = 1;
					isMoving = 1;
					++k;
					continue;
				}

				if(tmp[i][k].Num() == tmp[i][j].Num() && !beMerged[i][k])
				{
					p_tochange[i][k] =  1;
					beMerged[i][k] = 1;
					isMoving = 1;
					p_gamescores += 1<<tmp[i][k].Num();
					--p_blocks_num;
					++k;
					break;
				}else
				{
					if(k == j + 1)
					{
						cancopy = 0;
					}
					break;
				}
				++k;
			}
			--k;

			if(!cancopy)
			{
				continue;
			}
			p_tomove[i][k] = p_blocks[i][j];
			p_tochange[i][k] += p_blocks[i][j].Num();
			p_blocks[i][j] = Blocks(i,j);
			tmp[i][j] = Blocks(i,j);
			tmp[i][k] = p_tomove[i][k];
		}
	}

	//TODO False
	if(! isMoving)
	{
		//StopMoving();
		return 0;
	}

	return 1;
}



bool Game::DownaStep()
{

	bool isMoving = 0;
	Blocks tmp[6][6];
	bool beMerged[6][6];
	for(int i = 0; i < 6; ++i)
	{
		for(int j = 0; j < 6; ++j)
		{
			tmp[i][j] = p_blocks[i][j];
			beMerged[i][j] = 0;
		}
	}
	for(int i = 0; i < 6; ++i)
	{
		for(int j = 1; j < 6; ++j)
		{

			if(p_blocks[i][j].Num() == 0)
			{
				continue;
			}

			int k = j - 1;
			bool oneBlockMove = 1;
			bool cancopy = 1;
			while(k >= 0 && oneBlockMove)
			{
				oneBlockMove = 0;
				if(tmp[i][k].Num() == 0)
				{
					oneBlockMove = 1;
					isMoving = 1;
					--k;
					continue;
				}

				if(tmp[i][k].Num() == tmp[i][j].Num() && !beMerged[i][k])
				{
					p_tochange[i][k] =  1;
					beMerged[i][k] = 1;
					p_gamescores += 1<<tmp[i][k].Num();
					isMoving = 1;
					--p_blocks_num;
					--k;
					break;
				}else
				{
					if(k == j - 1)
					{
						cancopy = 0;
					}
					break;
				}
				--k;
			}
			++k;

			if(!cancopy)
			{
				continue;
			}
			p_tomove[i][k] = p_blocks[i][j];
			p_tochange[i][k] += p_blocks[i][j].Num();
			p_blocks[i][j] = Blocks(i,j);
			tmp[i][j] = Blocks(i,j);
			tmp[i][k] = p_tomove[i][k];
		}
	}

	//TODO False
	if(! isMoving)
	{
		//StopMoving();
		return 0;
	}


	return 1;
}


bool Game::RightaStep()
{

	bool isMoving = 0;
	Blocks tmp[6][6];
	bool beMerged[6][6];
	for(int i = 0; i < 6; ++i)
	{
		for(int j = 0; j < 6; ++j)
		{
			tmp[i][j] = p_blocks[i][j];
			beMerged[i][j] = 0;
		}
	}
	for(int j = 0; j < 6; ++j)
	{
		for(int i = 4; i >= 0; --i)
		{

			if(p_blocks[i][j].Num() == 0)
			{
				continue;
			}

			int k = i + 1;
			bool oneBlockMove = 1;
			bool cancopy = 1;
			while(k <= 5 && oneBlockMove)
			{
				oneBlockMove = 0;
				if(tmp[k][j].Num() == 0)
				{
					oneBlockMove = 1;
					isMoving = 1;
					++k;
					continue;
				}

				if(tmp[k][j].Num() == tmp[i][j].Num() && !beMerged[k][j])
				{
					p_tochange[k][j] =  1;
					beMerged[k][j] = 1;
					p_gamescores += 1<<tmp[k][j].Num();
					isMoving = 1;
					--p_blocks_num;
					++k;
					break;
				}else
				{
					if(k == i + 1)
					{
						cancopy = 0;
					}
					break;
				}
				++k;
			}
			--k;

			if(!cancopy)
			{
				continue;
			}
			p_tomove[k][j] = p_blocks[i][j];
			p_tochange[k][j] += p_blocks[i][j].Num();
			p_blocks[i][j] = Blocks(i,j);
			tmp[i][j] = Blocks(i,j);
			tmp[k][j] = p_tomove[k][j];
		}
	}

	//TODO False
	if(! isMoving)
	{
		//StopMoving();
		return 0;
	}

	return 1;
}



bool Game::LeftaStep()
{

	bool isMoving = 0;
	Blocks tmp[6][6];
	bool beMerged[6][6];
	for(int i = 0; i < 6; ++i)
	{
		for(int j = 0; j < 6; ++j)
		{
			tmp[i][j] = p_blocks[i][j];
			beMerged[i][j] = 0;
		}
	}
	for(int j = 0; j < 6; ++j)
	{
		for(int i = 1; i < 6; ++i)
		{

			if(p_blocks[i][j].Num() == 0)
			{
				continue;
			}

			int k = i - 1;
			bool oneBlockMove = 1;
			bool cancopy = 1;
			while(k >= 0 && oneBlockMove)
			{
				oneBlockMove = 0;
				if(tmp[k][j].Num() == 0)
				{
					oneBlockMove = 1;
					isMoving = 1;
					--k;
					continue;
				}

				if(tmp[k][j].Num() == tmp[i][j].Num() && !beMerged[k][j])
				{
					p_tochange[k][j] =  1;
					beMerged[k][j] =1;
					isMoving = 1;
					p_gamescores += 1<<tmp[k][j].Num();
					--p_blocks_num;
					--k;
					break;
				}else
				{
					if(k == i - 1)
					{
						cancopy = 0;
					}
					break;
				}
				--k;
			}
			++k;

			if(!cancopy)
			{
				continue;
			}
			p_tomove[k][j] = p_blocks[i][j];
			p_tochange[k][j] += p_blocks[i][j].Num();
			p_blocks[i][j] = Blocks(i,j);
			tmp[i][j] = Blocks(i,j);
			tmp[k][j] = p_tomove[k][j];
		}
	}

	//TODO False
	if(! isMoving)
	{
		//StopMoving();
		return 0;
	}


	return 1;
}


// for(int i = 0; i < 6; ++i)
// {
// 	for(int j = 0; j < 6; ++j)
// 	{
// 		std::cout<<p_tochange[i][j]<<" ";
// 	}
// 	std::cout<<"\n";
// }

// 	for(int j = 4; j >= 0; --j)
// 	{
// 		for(int i = 0; i <= 6; ++i)
// 		{
// 			if( p_blocks[i][j].Num() == 0)
// 			{
// 				continue;
// 			}
// 
// 			if(p_blocks[i][j+1].Num() == 0)
// 			{
// 			
// 				p_tomove[i][j+1] = p_blocks[i][j];
// 				p_blocks[i][j] = Blocks(i,j);
// 				isMoving = 1;
// 			}else
// 			{
// 				if(p_blocks[i][j+1].Num() == p_blocks[i][j].Num())
// 				{
// 					p_tochange[i][j+1] = ( p_blocks[i][j].Num() + 1 ) % 11;
// 					p_tomove[i][j+1] = p_blocks[i][j];
// 					p_blocks[i][j] = Blocks(i,j);
// 					isMoving = 1;
// 				}
// 			}
// 		}
// 	}




// void Game::StopMoving()
// {
// 	for(int i = 0; i < 6; ++i)
// 	{
// 		for(int j = 0; j < 6; ++j)
// 		{
// 			if(p_tomove[i][j].Num() != 0)
// 			{
// 				p_blocks[i][i] = Blocks(i,j,( p_tomove[i][j].Num() + p_tochange[i][j]) );
// 			}
// 			p_tomove[i][j] = Blocks(i,j);
// 			p_tochange[i][j] = 0;
// 		}
// 	}
// }
// 
// void Game::toUp()
// {
// 	if(p_gameState != Constants::Ready)
// 	{
// 		return ;
// 	}
// 	p_gameState = Constants::Busy;
// 
// 	int edgepos[6];
// 	Blocks edge[6];
// 	bool ismove = 0;
// 	for(int i = 0; i < 6; ++i)
// 	{
// 		edge[i] = p_blocks[i][5];
// 		edgepos[i] = 5;
// 	}
// 
// 	for(int j = 4; j >= 0; --j)
// 	{
// 		for(int i = 0; i < 6; ++i)
// 		{
// 			if(p_blocks[i][j].Num()!=0)
// 			{
// 				if(edge[i].Num() == 0)
// 				{
// 					edge[i] = p_blocks[i][j];
// 					p_tomove[i][edgepos[i]] = p_blocks[i][j];
// 					p_tochange[i][edgepos[i]] = 0;
// 
// 					p_blocks[i][j] = Blocks(i,j);
// 					ismove = 1;
// 					
// 				}else
// 				{
// 					if(edge[i].Num() == p_blocks[i][j].Num())
// 					{
// 						++edge[i];
// 						p_tomove[i][edgepos[i]] = p_blocks[i][j];
// 						p_tochange[i][edgepos[i]] = 1;
// 
// 						p_blocks[i][j] = Blocks(i,j);
// 						ismove = 1;
// 					}else if(edgepos[i] != j - 1)
// 					{
// 						++edgepos[i];
// 						edge[i] = p_blocks[i][j];
// 						if(edgepos[i] != j - 1)
// 						{
// 							p_tomove[i][edgepos[i]] = p_blocks[i][j];
// 							p_tochange[i][edgepos[i]]  = 0;
// 
// 							p_blocks[i][j] = Blocks(i,j);
// 							ismove = 1;
// 						}
// 					}
// 
// 				}
// 			}
// 		}
// 	}
// 	if(!ismove)
// 	{
// 		p_gameState = Constants::Ready;
// 		return;
// 	}
// 	while(ismove)
// 	{
// 		ismove = 0;
// 		for(int i = 0; i < 6; ++i)
// 		{
// 			for(int j = 0; j < 6; ++j)
// 			{
// 				if(p_tomove[i][j].move(i, j))
// 				{
// 					ismove = 1;
// 				}
// 			}
// 		}
// 		UpDate();
// 	}
// 
// 	StopMoving();
// 	p_gameState = Constants::Ready;
// }
// 
